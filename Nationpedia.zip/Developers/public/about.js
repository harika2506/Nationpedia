$(init);

function init()
{
    $("#accordion").accordion();
}
