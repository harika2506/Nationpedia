
$(init);

function init()
{
    $("#tabs").tabs();
}